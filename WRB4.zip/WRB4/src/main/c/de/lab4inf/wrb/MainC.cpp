#include <iostream>
#include <math.h>
#include "Function.h"
#include "Differentiator.h"
#include "Integrator.h"
#include "CUnit.h"

void testFunction(Function &f, double from, double to, double by, double eps) {
    printf("\nTesting function %s\n", f.name());
    printf("      x       |       f(x)        |        f'(x)      |       F(x)       | f'# |  F#       \n");
    printf("--------------+-------------------+-------------------+------------------+-----+----------\n");

    for (double x = from; x <= to; x += by) {
        printf("  %+10f  |  %+15f  |  %+15f  |  %+15f |", x, f(x), differentiate(f, x, eps),
               integrate(f, 0.0, x, eps));
        //printf("  %i  | %5i  \n", functionCallCounterDifferentiator, functionCallCounterIntegrator);


    }
}

double xx(double x) {
    //functionCallCounterIntegrator++;
    return x * x;
}

double sin(double x){
    //functionCallCounterIntegrator++;
    return sin(x);
}

double exp(double x){
    //functionCallCounterIntegrator++;
    return exp(x);
}

double tan(double x){
    //functionCallCounterIntegrator++;
    return tan(x);
}

double poly4(double x){
    //functionCallCounterIntegrator++;
    return (5*x*x*x*x + 4*x*x*x + 3*x*x+2*x + 1);
}

int main() {
    double eps = 1.e-8;
    Function f = Function(xx, "x^2");
    testFunction(f, 0, 1, 0.25, eps);

    f = Function(exp, "exp");
    testFunction(f, 0, 10, 1, eps);

    f = Function(sin, "sin");
    testFunction(f, 0, 3.2, M_PI / 8, eps);

    f = Function(tan, "tan");
    testFunction(f, 0, 0.8, M_PI / 16, eps);

    f = Function(poly4, "5x^4+4x^3+3x^2+2x+1");
    testFunction(f,0,3,0.25,eps);




    return 0;
}
