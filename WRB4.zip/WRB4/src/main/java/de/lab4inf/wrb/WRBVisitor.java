package de.lab4inf.wrb;

import java.util.HashMap;
import java.util.Map;
import org.antlr.v4.runtime.tree.ParseTree;


public class WRBVisitor extends GrammarBaseVisitor<Double>{
	/** "memory" for our calculator; variable/value pairs go here */
	Map<String, Double> memory = new HashMap<String, Double>();
	Map<String, Function> functionmemory = new HashMap<String, Function>(); 
	
	/** ID '=' expr */
	@Override
	public Double visitAssign(GrammarParser.AssignContext ctx) {
		String id = ctx.ID().getText(); //LETTER is left-hand side of '='
		double value = visit(ctx.expr());		//compute value of expression on right
		memory.put(id, value);				//store it in our memory
		return value;
	}
	/** expr */
    @Override
    public Double visitOnlyExpr(GrammarParser.OnlyExprContext ctx) {
    	Double value = visit(ctx.expr()); // evaluate the expr child
        return value;                          // return dummy value
    }

    /** number */
    @Override
    public Double visitFloat(GrammarParser.FloatContext ctx) {
        return Double.valueOf(ctx.newnumber().getText());
    }

    /** ID */
    @Override
    public Double visitId(GrammarParser.IdContext ctx) {
        String id = ctx.ID().getText();
        if ( memory.containsKey(id) ) return memory.get(id);
        throw new IllegalArgumentException("ID nicht gefunden");
    }

    /** expr op=('*'|'/') expr */
    @Override
    public Double visitMulDiv(GrammarParser.MulDivContext ctx) {
        double left = visit(ctx.expr(0));  // get value of left subexpression
        double right = visit(ctx.expr(1)); // get value of right subexpression
        if ( ctx.op.getType() == GrammarParser.MUL ) return left * right;
        return left / right; // must be DIV
    }

    /** expr op=('+'|'-') expr */
    @Override
    public Double visitAddSub(GrammarParser.AddSubContext ctx) {
    	double left = visit(ctx.expr(0));  // get value of left subexpression
    	double right = visit(ctx.expr(1)); // get value of right subexpression
        if ( ctx.op.getType() == GrammarParser.ADD ) return left + right;
        return left - right; // must be SUB
    }
    
    /** expr op=('^'|'**') expr */
    @Override
    public Double visitPower(GrammarParser.PowerContext ctx) {
    	double left = visit(ctx.expr(0));  // get value of left subexpression
    	double right = visit(ctx.expr(1)); // get value of right subexpression
        return Math.pow(left, right); 
    }

    /** '(' expr ')' */
    @Override
    public Double visitParens(GrammarParser.ParensContext ctx) {
    	if(ctx.SUB()!=null)
    		return -1*visit(ctx.expr());
        return visit(ctx.expr()); // return child expr's value
    }
    
    /** ID '(' expr (',' expr)* ')' */
    @Override
    public Double visitFunction(GrammarParser.FunctionContext ctx) {
    	String name = ctx.ID().getText();
    	int argCount = ctx.expr().size();
    	double[] argList = new double[argCount];
		for(int i=0;i<argCount;i++) {
			argList[i] = visit(ctx.expr(i));
		}
		
		if(functionmemory.containsKey(name)) {
			Function f = functionmemory.get(name);
			return f.eval(argList);
		}
		else
			throw new IllegalArgumentException(String.format("Unbekannte Funktion %s ",name));
    }
    
    /** ID '(' ID (',' ID)* ')' '=' expr */
    @Override
    public Double visitFunctionassign(GrammarParser.FunctionassignContext ctx) {
    	String name = ctx.ID(0).getText();
    	int argCount = ctx.ID().size()-1;
    	String[] argList= new String[argCount];
    	for(int i=0;i<argCount;i++)
			argList[i] = ctx.ID(i+1).getText();
    	ParseTree body = ctx.expr();
    	WRBFunction function= new WRBFunction(name, argList, body, WRBVisitor.this);
    	functionmemory.put(name, function);
    	return 0.0;
    }
    
    /** stat EOF */
    @Override
    public Double visitProg(GrammarParser.ProgContext ctx) {
    	return visit(ctx.getChild(0));
    }
    
    /** stat ';' (stat)? */
    @Override
    public Double visitStatconcat(GrammarParser.StatconcatContext ctx) {
    	int size=ctx.stat().size();
    	for(int i=0;i<size-1;i++)
    		visit(ctx.stat(i));
    	return visit(ctx.stat(size-1));
    }
	
}