package de.lab4inf.wrb;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ConsoleErrorListener;
import org.antlr.v4.runtime.DefaultErrorStrategy;
import org.antlr.v4.runtime.atn.PredictionMode;
import org.antlr.v4.runtime.misc.ParseCancellationException;
import org.antlr.v4.runtime.tree.ParseTree;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

public class WRBScript implements Script{
    private WRBVisitor Visitor;
    
    public WRBScript() {
    	Visitor = new WRBVisitor();
    	addMathFunctions();
    }

    @Override
    public double parse(String definition) {
        GrammarLexer lexer = new GrammarLexer(CharStreams.fromString(definition));
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        lexer.removeErrorListeners();
		lexer.addErrorListener(WRBConsoleErrorListener.INSTANCE);
        
		GrammarParser parser = new GrammarParser(tokens);
        parser.setTokenStream(tokens);
        parser.getInterpreter().setPredictionMode(PredictionMode.SLL);
		parser.removeErrorListeners();
		parser.addErrorListener(WRBConsoleErrorListener.INSTANCE);
        
        ParseTree tree;
        Double ergebnis;
        
        try {
        	tree = parser.prog();
        	ergebnis = Visitor.visit(tree);
		} catch (ParseCancellationException e) {
			lexer.reset();
			parser.reset();
			parser.addErrorListener(ConsoleErrorListener.INSTANCE);
			parser.setErrorHandler(new DefaultErrorStrategy());
			parser.getInterpreter().setPredictionMode(PredictionMode.LL);
			tree = parser.prog();
        	ergebnis = Visitor.visit(tree);
		}
        return ergebnis;
        
    }
    
    public void addMathFunctions() {
    	setFunction("sin", 		(x) -> Math.sin(x[0]));
    	setFunction("asin", 	(x) -> Math.asin(x[0])); 
    	setFunction("sinh", 	(x) -> Math.sinh(x[0]));
    	setFunction("cos", 		(x) -> Math.cos(x[0]));
    	setFunction("acos", 	(x) -> Math.acos(x[0]));
    	setFunction("cosh", 	(x) -> Math.cosh(x[0]));
    	setFunction("abs", 		(x) -> Math.abs(x[0]));
    	setFunction("tan", 		(x)	-> Math.tan(x[0]));
    	setFunction("atan", 	(x)	-> Math.atan(x[0]));
    	setFunction("exp", 		(x) -> Math.exp(x[0]));
    	setFunction("sqrt", 	(x) -> Math.sqrt(x[0]));
    	setFunction("pow", 		(x) -> Math.pow(x[0], x[1]));
		setFunction("log2",	 	(x) -> Math.log(x[0])/Math.log(2));
		setFunction("ld", 		(x) -> Math.log(x[0])/Math.log(2));
		setFunction("lb", 		(x) -> Math.log(x[0])/Math.log(2));
		setFunction("ln", 		(x) -> Math.log(x[0]));
		setFunction("logE", 	(x) -> Math.log(x[0]));
		setFunction("log", 		(x) -> Math.log10(x[0]));
		setFunction("log10",	(x)	-> Math.log10(x[0]));
		setFunction("max", 		(x) -> getMaxOfDoubleArray(x));
		setFunction("min", 		(x) -> getMinOfDoubleArray(x));

    }
    
    public double getMaxOfDoubleArray(double[] arr) {
		if(arr == null || arr.length ==0)
			throw new IllegalArgumentException();
		
		double max = arr[0];
		for(int i = 0; i < arr.length; i++) 
		{
			if(arr[i] > max)
				max = arr[i];
		}
		return max;
	}
	
	public double getMinOfDoubleArray(double[] arr) {
		if(arr == null || arr.length ==0)
			throw new IllegalArgumentException();
		
		double min = arr[0];
		for(int i = 0; i < arr.length; i++) 
		{
			if(arr[i] < min)
				min = arr[i];
		}
		return min;
	}


    @Override
    public double parse(InputStream defStream) throws IOException {
        return parse(IOUtils.toString(defStream, "UTF-8"));
    }

    @Override
    public Set<String> getFunctionNames() {
        return Visitor.functionmemory.keySet();
    }


    @Override
    public Set<String> getVariableNames() {
        return Visitor.memory.keySet();
    }

    @Override
    public void setFunction(String name, Function fct) {
    	Visitor.functionmemory.put(name, fct);
    }

    @Override
    public Function getFunction(String name) {
    	if(!Visitor.functionmemory.containsKey(name))
    		throw new IllegalArgumentException();
        return Visitor.functionmemory.get(name);
    }

    @Override
    public double getVariable(String name) {
        try {
            return Visitor.memory.get(name);
        } catch (NullPointerException exception) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public void setVariable(String name, double value) {
    	Visitor.memory.put(name, value);
    }
    
    @Override
    public Script concat(Script that) {
    	Script newScript=new WRBScript();
        // old fashion JDK 1.5 for-loop
        for (String varName : that.getVariableNames()) {
            double var = that.getVariable(varName);
            newScript.setVariable(varName, var);
        }
        // new style for-each-loop with lambda expression
        this.getFunctionNames().forEach((fctName) -> {
            newScript.setFunction(fctName, this.getFunction(fctName));
        });
        that.getFunctionNames().forEach((fctName) -> {
            newScript.setFunction(fctName, that.getFunction(fctName));
        }); 
        return newScript;
    }
    
}