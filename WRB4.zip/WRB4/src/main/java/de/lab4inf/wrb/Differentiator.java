package de.lab4inf.wrb;

import java.util.logging.Logger;

public class Differentiator {
    static final Logger logger = java.util.logging.Logger.getLogger("de.lab4inf");
    private double eps = 1.E-9;
    static {
        try {
            String libName = "WRB4";
            System.loadLibrary(libName);
        } catch (Throwable error) {
            logger.severe("LibPath: " + System.getProperty("java.library.path"));
            logger.severe("native lib loading failed " + error);
            System.exit(-1);
        }
    }

    public double differentiate(Function f, double a) {
        return differentiate(f, a, eps);
    }

    public native double differentiate(Function f, double a, double eps);

    public double getEps() {
        return eps;
    }

    public void setEps(double eps) {
        this.eps = eps;
    }

}
